<?php
/**
 * Template for displaying audio post format item content
 */

tm_divi_post_format_content();
